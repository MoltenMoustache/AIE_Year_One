#include "Zergling.h"



Zergling::Zergling()
{
	maxHealth = 12;
	health = maxHealth;
	maxDamage = 5;
}


Zergling::~Zergling()
{
}
