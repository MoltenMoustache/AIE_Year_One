#include "Marine.h"



Marine::Marine()
{
	maxHealth = 25;
	health = maxHealth;
	maxDamage = 12;
}


Marine::~Marine()
{
}
